/*
 * @Author: skybluefeet
 * @Date: 2020-03-04 10:50:30
 * @LastEditors: skybluefeet
 * @LastEditTime: 2020-03-04 11:17:11
 */
import VLink from "./link.vue";

export default VLink;
