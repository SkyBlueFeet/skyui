/*
 * @Date: 2020-03-15 18:46:46
 * @LastEditors: skyblue
 * @LastEditTime: 2020-03-23 18:45:38
 * @repository: https://github.com/SkyBlueFeet
 */
import VImage from "./image.vue";

export default VImage;
