import PopConfirm from "./PopConfirm.vue";

export default PopConfirm;
