<template>
  <div class="timeline">
    <slot></slot>
  </div>
</template>
