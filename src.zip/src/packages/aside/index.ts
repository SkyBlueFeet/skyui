import Aside from "./Aside.vue";

export default Aside;
