import Tooltip from "./Tooltip.vue";

export default Tooltip;
