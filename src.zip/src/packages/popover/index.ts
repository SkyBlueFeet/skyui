import Popover from "./Popover.vue";

export default Popover;
