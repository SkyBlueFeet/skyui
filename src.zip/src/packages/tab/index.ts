import Tabs from "./Tabs.vue";
import TabItem from "./TabItem.vue";

export { Tabs, TabItem };
