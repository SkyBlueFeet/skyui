import Affix from "./Affix.vue";
export default Affix;
