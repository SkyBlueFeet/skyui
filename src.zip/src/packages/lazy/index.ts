/*
 * @Date: 2020-03-19 21:46:49
 * @LastEditors: skyblue
 * @LastEditTime: 2020-03-19 21:46:49
 * @repository: https://github.com/SkyBlueFeet
 */
import VLazy from "./VueLazyComponent.vue";

export default VLazy;
