import InputNumber from "./InputNumber.vue";

export default InputNumber;
