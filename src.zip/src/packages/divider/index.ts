/*
 * @Author: skybluefeet
 * @Date: 2020-03-03 17:30:01
 * @LastEditors: skybluefeet
 * @LastEditTime: 2020-03-03 20:29:45
 */
import VDivider from "./divider.vue";

export default VDivider;
