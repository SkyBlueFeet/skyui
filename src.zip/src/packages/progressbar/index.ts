import ProgressBar from "./ProgressBar.vue";

export default ProgressBar;
