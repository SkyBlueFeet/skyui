import Switch from "./Switch.vue";

export default Switch;
