/*
 * @Author: skybluefeet
 * @Date: 2020-03-03 12:38:42
 * @LastEditors: skybluefeet
 * @LastEditTime: 2020-03-03 14:40:12
 */
import VIcon from "./icon.vue";

export default VIcon;
