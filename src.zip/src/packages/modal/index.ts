import Modal from "./Modal.vue";

export default Modal;
