/*
 * @Author: skybluefeet
 * @Date: 2020-03-04 15:12:30
 * @LastEditors: skyblue
 * @LastEditTime: 2020-03-15 12:59:17
 */

/**
 * 基于https://github.com/zwhGithub/vue-swiper实现
 */

import VSlide from "./slide.vue";

import VSwiper from "./swiper.vue";

export { VSlide, VSwiper };
