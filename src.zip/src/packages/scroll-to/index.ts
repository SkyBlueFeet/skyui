import ScrollTo from "./ScrollTo.vue";

export default ScrollTo;
