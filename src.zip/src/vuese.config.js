/*
 * @Author: skybluefeet
 * @Date: 2020-02-27 01:35:35
 * @LastEditors: skybluefeet
 * @LastEditTime: 2020-03-04 10:41:14
 */
module.exports = {
  genType: "markdown",
  include: ["packages/**"],
  outDir: "../docs",
  markdownDir: "docs"
};
